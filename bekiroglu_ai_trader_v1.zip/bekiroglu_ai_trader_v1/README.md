# BEKİROĞLU AI TRADER v1.0

iPhone tarayıcısından kullanılabilecek, Streamlit tabanlı çoklu piyasa tarayıcısı ve sanal işlem demosu.

## Bu sürüm ne yapar?
- ABD hisseleri, kripto ve döviz sembollerini Yahoo Finance üzerinden tarar.
- EMA20, EMA50 ve RSI(14) hesaplar.
- Basit ve açıklanabilir AL / BEKLE / İZLE sinyali üretir.
- 1.000 USD sanal bakiye ile manuel sanal alım/satım kaydı tutar.
- Kaldıraç veya gerçek emir gönderimi yoktur.

## Önemli sınırlar
- Bu bir yatırım tavsiyesi veya kâr garantisi değildir.
- "AI" adı proje markasıdır; v1.0 sinyalleri makine öğrenmesi/LLM değil kural tabanlıdır.
- Yahoo Finance verisi gecikebilir, eksik olabilir veya erişilemeyebilir.
- Sanal işlem geçmişi Streamlit oturum belleğinde tutulur; oturum kapanırsa sıfırlanabilir.
- İlk sürümde otomatik işlem, haber analizi, stop emri ile gerçek broker bağlantısı yoktur.

## iPhone ile ücretsiz yayınlama (Streamlit Community Cloud)
1. iPhone'da Safari ile GitHub hesabı açın veya giriş yapın: https://github.com
2. GitHub'da `New repository` seçin. Repository adı: `bekiroglu-ai-trader`. Public seçebilirsiniz; bu projede gizli anahtar bulunmaz.
3. Bu ZIP'i iPhone Dosyalar uygulamasında açın. İçindeki `app.py`, `requirements.txt` ve `README.md` dosyalarını bulun.
4. GitHub deposunda `Add file` > `Upload files` seçin; bu üç dosyayı yükleyip `Commit changes` düğmesine basın.
5. Safari'de https://share.streamlit.io adresini açın ve GitHub ile giriş yapın.
6. `Create app` / `Deploy an app` seçin.
7. Repository: `bekiroglu-ai-trader`; branch: `main`; Main file path: `app.py` seçin.
8. `Deploy` düğmesine basın. İlk kurulum birkaç dakika sürebilir.
9. Açılan Streamlit bağlantısını iPhone ana ekranına eklemek için Safari paylaş menüsü > `Ana Ekrana Ekle` seçin.

Arayüz adları zamanla değişebilir. Streamlit Community Cloud ücretsiz kullanım ve erişim koşullarını kendi sitesinden kontrol edin.

## Yerel çalıştırma (bilgisayar varsa)
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
